﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour {
    public SimpleCharacterController controller;
    // Start is called before the first frame update
    void Start () {
        if (controller == null) {
            controller = GetComponent<SimpleCharacterController> ();
        }
    }

    public void SetPlayerSpeed (float newSpeed) {
        controller.speed = newSpeed;
    }
    public void SetPlayerJumpHeight (float newHeight) {
        controller.jumpSpeed = newHeight;
    }
    public void SetRegenSpeed (InteractableColor type, float newRegen) {
        switch (type) {
            case InteractableColor.RED:
                {
                    PlayerUI.instance.redSlider.regenSpeed = newRegen;
                    break;
                }
            case InteractableColor.BLUE:
                {
                    PlayerUI.instance.blueSlider.regenSpeed = newRegen;
                    break;
                }
            case InteractableColor.GREEN:
                {
                    PlayerUI.instance.greenSlider.regenSpeed = newRegen;
                    break;
                }
            default:
                {
                    Debug.LogWarning ("Tried to set regen speed on null value!");
                    break;
                }
        }
    }

    // Update is called once per frame
    void Update () {

    }
}